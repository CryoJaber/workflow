window.JoomlaCalLocale = {
	today : "Idag",
	weekend : [0, 6],
	wk : "vk",
	time : "Tid:",
	days : ["Söndag", "Måndag", "Tisdag", "Onsdag", "Torsdag", "Fredag", "Lördag"],
	shortDays : ["Sön", "Mån", "Tis", "Ons", "Tor", "Fre", "Lör"],
	months : ["Januari", "Februari", "Mars", "April", "Maj", "Juni", "Juli", "Augusti", "September", "Oktober", "November", "December"],
	shortMonths : ["Jan", "Feb", "Mar", "Apr", "Maj", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dec"],
	AM : "FM",
	PM :  "EM",
	am : "fm",
	pm : "em",
	dateType : "gregorian",
	minYear : 1900,
	maxYear : 2100,
	exit: "Stäng",
	clear: "Rensa"
};