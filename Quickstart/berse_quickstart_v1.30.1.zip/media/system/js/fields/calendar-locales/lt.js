window.JoomlaCalLocale = {
	today : "Šiandien",
	weekend : [0, 6],
	wk : "wk",
	time : "Laikas:",
	days : ["Sekmadienis", "Pirmadienis", "Antradienis", "Trečiadienis", "Ketvirtadienis", "Penktadienis", "Šeštadienis"],
	shortDays : ["Sek", "Pir", "Ant", "Tre", "Ket", "Pen", "Šeš"],
	months : ["Sausis", "Vasaris", "Kovas", "Balandis", "Gegužė", "Birželis", "Liepa", "Rugpjūtis", "Rugsšjis", "Spalis", "Lapkritis", "Gruodis"],
	shortMonths : ["Sau", "Vas", "Kov", "Bal", "Geg", "Bir", "Lie", "Rug", "Rgs", "Spa", "Lap", "Grd"],
	AM : "AM",
	PM :  "PM",
	am : "am",
	pm : "pm",
	dateType : "gregorian",
	minYear : 1900,
	maxYear : 2100,
	exit: "Uždaryti",
	clear: "Išvalyti"
};