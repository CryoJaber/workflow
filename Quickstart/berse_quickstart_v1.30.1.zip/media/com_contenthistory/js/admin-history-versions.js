/**
 * @copyright  Copyright (C) 2005 - 2020 Open Source Matters, Inc. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
window.addEventListener('DOMContentLoaded', function() {
	document.body.appendChild(document.getElementById('versionsModal'));
});
