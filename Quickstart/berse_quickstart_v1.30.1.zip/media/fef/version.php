<?php
/*
 * Akeeba Frontend Framework (FEF)
 *
 * @package   fef
 * @copyright (c) 2017-2021 Nicholas K. Dionysopoulos / Akeeba Ltd
 * @license   GNU General Public License version 3, or later
 */

// Protect from unauthorized access
defined('_JEXEC') or die;

define('AKEEBAFEF_VERSION', '2.0.2');
define('AKEEBAFEF_DATE', '2021-03-11');
